<?php

/**
 * @Author: nguyen
 * @Date:   2020-02-17 13:58:49
 * @Last Modified by:   nguyen
 * @Last Modified time: 2020-02-17 13:59:10
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magepow_Lazyload',
    __DIR__
);
