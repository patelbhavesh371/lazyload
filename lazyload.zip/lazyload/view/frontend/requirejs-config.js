var config = {

	paths: {
		'magepow/lazyload'			: 'Magepow_Lazyload/js/plugins/lazyload.min',
	},

	shim: {
		'magepow/lazyload': {
			deps: ['jquery']
		}
	}

};
